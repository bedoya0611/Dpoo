package uniandes.dpoo.aerolinea.modelo;

import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
    private String fecha;
    private Ruta ruta;
    private Avion avion;
    private Map<String, Tiquete> tiquetes;
    private boolean realizado = false;

    public Vuelo(Ruta ruta, String fecha, Avion avion) {
        this.fecha = fecha;
        this.ruta = ruta;
        this.avion = avion;
        this.tiquetes = new HashMap<>();
    }

    public String getFecha() {
        return fecha;
    }

    public Ruta getRuta() {
        return ruta;
    }
    
    public Avion getAvion() {
        return avion;
    }
    
    public Map<String, Tiquete> getTiquetes() {
        return tiquetes;
    }
    
    public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws VueloSobrevendidoException {
        if (tiquetes.size() + cantidad > avion.getCapacidad()) {
            throw new VueloSobrevendidoException(null);
        }
        //Utiliza el prefijo "TQ", los códigos de aeropuertos de origen y destino, la fecha (sin guiones)
        //y un contador basado en la cantidad de tiquetes ya vendidos
        int tarifa = calculadora.calcularTarifa(this, cliente);
        for (int i = 0; i < cantidad; i++) {
            String codigoTiquete = "TQ-" + this.ruta.getOrigen().getCodigo() + "-" + this.ruta.getDestino().getCodigo() 
                                    + "-" + fecha.replace("-", "") + "-" + (tiquetes.size() + 1);
            Tiquete nuevoTiquete = new Tiquete(codigoTiquete, this, cliente, tarifa);
            tiquetes.put(codigoTiquete, nuevoTiquete);
            cliente.agregarTiquete(nuevoTiquete);
        }
        
        return cantidad;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vuelo other = (Vuelo) obj;
        return fecha.equals(other.fecha) && ruta.equals(other.ruta) && avion.equals(other.avion);
    }

	public void marcarComoRealizado() {
		realizado = true;
		
	}
}
