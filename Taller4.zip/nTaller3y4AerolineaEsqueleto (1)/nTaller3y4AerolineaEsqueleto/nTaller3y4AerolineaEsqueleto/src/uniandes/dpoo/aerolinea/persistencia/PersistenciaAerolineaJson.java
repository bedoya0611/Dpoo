package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea {

    @Override
    public void cargarAerolinea(String archivo, Aerolinea aerolinea) throws IOException, InformacionInconsistenteException {
        String jsonCompleto = new String(Files.readAllBytes(new File(archivo).toPath()));
        JSONObject raiz = new JSONObject(jsonCompleto);

        List<Aeropuerto> aeropuertos = new ArrayList<>();
        List<Avion> aviones = new ArrayList<>();
        List<Ruta> rutas = new ArrayList<>();
        List<Vuelo> vuelos = new ArrayList<>();

        // Procesar y crear aeropuertos
        JSONArray aeropuertosJson = raiz.getJSONArray("aeropuertos");
        for (int i = 0; i < aeropuertosJson.length(); i++) {
            JSONObject obj = aeropuertosJson.getJSONObject(i);
            Aeropuerto aeropuerto = new Aeropuerto(
                    obj.getString("nombre"),
                    obj.getString("codigo"),
                    obj.getString("nombreCiudad"),
                    obj.getDouble("latitud"),
                    obj.getDouble("longitud"),
                    new HashSet<>()  // Suponemos que esta información no se carga desde JSON.
            );
            aeropuertos.add(aeropuerto);
        }

        // Procesar y crear aviones
        JSONArray avionesJson = raiz.getJSONArray("aviones");
        for (int i = 0; i < avionesJson.length(); i++) {
            JSONObject obj = avionesJson.getJSONObject(i);
            Avion avion = new Avion(
                    obj.getString("nombre"),
                    obj.getInt("capacidad")
            );
            aerolinea.agregarAvion(avion);
        }

        // Procesar y crear rutas
        JSONArray rutasJson = raiz.getJSONArray("rutas");
        for (int i = 0; i < rutasJson.length(); i++) {
            JSONObject obj = rutasJson.getJSONObject(i);
            Aeropuerto origen = aeropuertos.stream().filter(a -> a.getCodigo().equals(obj.getString("origen"))).findFirst().orElse(null);
            Aeropuerto destino = aeropuertos.stream().filter(a -> a.getCodigo().equals(obj.getString("destino"))).findFirst().orElse(null);
            Ruta ruta = new Ruta(
                    origen,
                    destino,
                    obj.getString("horaSalida"),
                    obj.getString("horaLlegada"),
                    obj.getString("codigoRuta")
            );
            aerolinea.agregarRuta(ruta);
        }

        // Procesar y crear vuelos
        JSONArray vuelosJson = raiz.getJSONArray("vuelos");
        for (int i = 0; i < vuelosJson.length(); i++) {
            JSONObject obj = vuelosJson.getJSONObject(i);
            Ruta ruta = rutas.stream().filter(r -> r.getCodigoRuta().equals(obj.getString("codigoRuta"))).findFirst().orElse(null);
            Avion avion = aviones.stream().filter(a -> a.getNombre().equals(obj.getString("nombreAvion"))).findFirst().orElse(null);
            Vuelo vuelo = new Vuelo(
                    ruta,
                    obj.getString("fecha"),
                    avion
            );
            vuelos.add(vuelo);
        }

    }

	@Override
	public void salvarAerolinea(String archivo, Aerolinea aerolinea) {
		// TODO Auto-generated method stub

	}

}
