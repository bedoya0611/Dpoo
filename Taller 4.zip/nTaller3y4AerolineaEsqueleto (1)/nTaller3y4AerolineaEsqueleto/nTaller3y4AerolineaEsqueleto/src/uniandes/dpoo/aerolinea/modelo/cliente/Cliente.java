package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {

    private List<Tiquete> tiquetesSinUsar;
    private List<Tiquete> tiquetesUsados;

    public Cliente() {
        tiquetesSinUsar = new ArrayList<>();
        tiquetesUsados = new ArrayList<>();
    }

    public abstract String getTipoCliente();
    public abstract String getIdentificador();

    public void agregarTiquete(Tiquete tiquete) {
        tiquetesSinUsar.add(tiquete);
    }

    public int calcularValorTotalTiquetes() {
        int valorTotal = 0;
        for (Tiquete t : tiquetesSinUsar) {
            valorTotal += t.getTarifa();
        }
        for (Tiquete t : tiquetesUsados) {
            valorTotal += t.getTarifa();
        }
        return valorTotal;
    }

    public void usarTiquetes(Vuelo vuelo) {
        List<Tiquete> tiquetesParaUsar = new ArrayList<>();
        for (Tiquete t : tiquetesSinUsar) {
            if (t.getVuelo().equals(vuelo)) {
                tiquetesParaUsar.add(t);
            }
        }
        tiquetesSinUsar.removeAll(tiquetesParaUsar);
        tiquetesUsados.addAll(tiquetesParaUsar);
    }
}
