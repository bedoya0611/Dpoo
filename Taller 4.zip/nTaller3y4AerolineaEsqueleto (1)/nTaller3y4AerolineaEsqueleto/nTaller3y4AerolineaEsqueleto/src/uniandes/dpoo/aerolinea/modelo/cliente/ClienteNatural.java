package uniandes.dpoo.aerolinea.modelo.cliente;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class ClienteNatural extends Cliente {

    public static final String NATURAL = "Natural";
    private String nombre;

    public ClienteNatural(String nombre) {
        super(); // Asegurarse de que se llame al constructor de la superclase
        this.nombre = nombre;
    }

    @Override
    public String getTipoCliente() {
        return NATURAL;
    }

    @Override
    public String getIdentificador() {
        // Podría ser simplemente el nombre, o algo más sofisticado dependiendo de los requisitos
        return nombre;
    }

    @Override
    public void agregarTiquete(Tiquete tiquete) {
        super.agregarTiquete(tiquete);
    }

    @Override
    public int calcularValorTotalTiquetes() {
        return super.calcularValorTotalTiquetes();
    }

    @Override
    public void usarTiquetes(Vuelo vuelo) {
        super.usarTiquetes(vuelo);
    }
}
