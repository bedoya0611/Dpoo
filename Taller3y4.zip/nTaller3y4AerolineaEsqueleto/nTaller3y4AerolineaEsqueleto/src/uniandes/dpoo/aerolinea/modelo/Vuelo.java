package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	private String fecha;

	public Vuelo(Ruta ruta, String fecha, Avion avion) {
		super();
		this.fecha = fecha;
	}

	public String getFecha() {
		return fecha;
	}

	public Ruta getRuta() {
		return null;
	}
	
	public Avion getAvion() {
		return null;
	}
	
	public Collection<Tiquete> getTiquetes() {
		return null;
	}
	
	
}
