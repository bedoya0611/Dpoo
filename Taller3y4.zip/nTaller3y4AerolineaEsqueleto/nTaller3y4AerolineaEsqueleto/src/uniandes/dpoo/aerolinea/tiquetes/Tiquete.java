package uniandes.dpoo.aerolinea.tiquetes;

import java.util.HashSet;
import java.util.Set;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class Tiquete {
    private String codigo;
    private int tarifa;
    private boolean usado;
    
    
	public Tiquete(String codigo, Vuelo vuelo, Cliente cliente, int tarifa) {
		super();
		this.codigo = codigo;
		this.tarifa = tarifa;
	}
	
	public String getCodigo() {
		return codigo;
	}
	public int getTarifa() {
		return tarifa;
	}
	public boolean isUsado() {
		return usado;
	}
    
    public void marcarComoUsado() {
    	
    }
    
    public boolean esUsado() {
    	return false;
    }

	public Vuelo getVuelo() {
		// TODO Auto-generated method stub
		return null;
	}

	public Cliente getCliente() {
		// TODO Auto-generated method stub
		return null;
	}
}

