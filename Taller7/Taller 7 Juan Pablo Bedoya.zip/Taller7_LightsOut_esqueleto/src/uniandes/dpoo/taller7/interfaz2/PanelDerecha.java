package uniandes.dpoo.taller7.interfaz2;

import javax.swing.*;

public class PanelDerecha extends JPanel {
	private static final long serialVersionUID = 1L;
	private JButton nuevoBtn;
    private JButton reiniciarBtn;
    private JButton top10Btn;
    private JButton cambiarJugadorBtn;

    public PanelDerecha() {
        // Configurar el layout del panel
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // Crear los botones
        nuevoBtn = new JButton("NUEVO");
        reiniciarBtn = new JButton("REINICIAR");
        top10Btn = new JButton("TOP-10");
        cambiarJugadorBtn = new JButton("CAMBIAR JUGADOR");

        // A�adir los botones al panel
        add(nuevoBtn);
        add(reiniciarBtn);
        add(top10Btn);
        add(cambiarJugadorBtn);
    }
}
