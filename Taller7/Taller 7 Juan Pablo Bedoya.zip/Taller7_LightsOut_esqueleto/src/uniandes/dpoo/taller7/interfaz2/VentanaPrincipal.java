package uniandes.dpoo.taller7.interfaz2;

import javax.swing.*;
import com.formdev.flatlaf.FlatLightLaf;
import java.io.Serializable;
import java.awt.*;

public class VentanaPrincipal extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;

    private PanelSuperior panelSuperior;
    private PanelDerecha panelDerecha;
    private PanelInferior panelInferior;
    
    public VentanaPrincipal() {
        // Configurar la ventana principal
        setTitle("Juego de LightsOut");
        setSize(800, 600); // Tama�o por defecto
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setLayout(new BorderLayout());

        // Inicializar los paneles
        panelSuperior = new PanelSuperior();
        panelDerecha = new PanelDerecha();
        panelInferior = new PanelInferior();

        // A�adir los paneles a la ventana principal
        add(panelSuperior, BorderLayout.NORTH);
        add(panelDerecha, BorderLayout.EAST);
        add(panelInferior, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        // Aplicar el tema FlatLightLaf
        FlatLightLaf.install();

        // Crear y mostrar la ventana principal
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}
