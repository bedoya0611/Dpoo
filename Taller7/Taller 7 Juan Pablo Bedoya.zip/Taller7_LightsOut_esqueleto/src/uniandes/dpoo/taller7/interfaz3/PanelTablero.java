package uniandes.dpoo.taller7.interfaz3;

import javax.swing.*;
import java.awt.*;

public class PanelTablero extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int tamano = 5; // Tama�o inicial del tablero

    public PanelTablero() {
        setPreferredSize(new Dimension(500, 500)); // Tama�o preferido del panel
    }

    public void setTamano(int nuevoTamano) {
        this.tamano = nuevoTamano;
        repaint(); // Redibujar el panel con el nuevo tama�o
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.YELLOW);

        int width = getWidth();
        int height = getHeight();
        int cellWidth = width / tamano;
        int cellHeight = height / tamano;

        for (int i = 0; i < tamano; i++) {
            for (int j = 0; j < tamano; j++) {
                int x = i * cellWidth;
                int y = j * cellHeight;
                g2d.fillRect(x, y, cellWidth, cellHeight);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(x, y, cellWidth, cellHeight);
                g2d.setColor(Color.YELLOW);
            }
        }
    }
}
