package uniandes.dpoo.taller7.interfaz3;

import javax.swing.*;
import java.awt.*;

public class PanelInferior extends JPanel {
	private static final long serialVersionUID = 1L;
	private JLabel jugadasLabel;
    private JTextField jugadasField;
    private JLabel jugadorLabel;
    private JTextField jugadorField;

    public PanelInferior() {
        // Configurar el layout del panel
        setLayout(new FlowLayout(FlowLayout.LEFT));

        // Crear los elementos del panel
        jugadasLabel = new JLabel("Jugadas:");
        jugadasField = new JTextField(5);
        jugadasField.setEditable(false);

        jugadorLabel = new JLabel("Jugador:");
        jugadorField = new JTextField(10);

        // A�adir los elementos al panel
        add(jugadasLabel);
        add(jugadasField);
        add(jugadorLabel);
        add(jugadorField);
    }
}
