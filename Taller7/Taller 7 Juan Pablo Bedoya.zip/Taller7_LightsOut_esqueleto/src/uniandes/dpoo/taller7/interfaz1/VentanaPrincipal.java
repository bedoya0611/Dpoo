package uniandes.dpoo.taller7.interfaz1;

import javax.swing.*;
import com.formdev.flatlaf.FlatLightLaf;
import java.io.Serializable;

public class VentanaPrincipal extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    
    public VentanaPrincipal() {
        setTitle("Juego de LightsOut");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        FlatLightLaf.install();

        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}
