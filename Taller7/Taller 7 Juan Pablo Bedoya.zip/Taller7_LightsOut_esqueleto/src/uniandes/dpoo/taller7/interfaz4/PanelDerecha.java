package uniandes.dpoo.taller7.interfaz4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelDerecha extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton nuevoBtn;
    JButton reiniciarBtn;
    JButton top10Btn;
    JButton cambiarJugadorBtn;

    public PanelDerecha(ActionListener actionListener) {
        // Configurar el layout del panel
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(43, 43, 43));
        
        // Crear los botones
        nuevoBtn = new JButton("NUEVO");
        reiniciarBtn = new JButton("REINICIAR");
        top10Btn = new JButton("TOP-10");
        cambiarJugadorBtn = new JButton("CAMBIAR JUGADOR");

        // Personalizar apariencia de los botones
        nuevoBtn.setForeground(Color.WHITE);
        reiniciarBtn.setForeground(Color.WHITE);
        top10Btn.setForeground(Color.WHITE);
        cambiarJugadorBtn.setForeground(Color.WHITE);
        
        nuevoBtn.setBackground(new Color(75, 110, 175));
        reiniciarBtn.setBackground(new Color(75, 110, 175));
        top10Btn.setBackground(new Color(75, 110, 175));
        cambiarJugadorBtn.setBackground(new Color(75, 110, 175));

        nuevoBtn.setFocusPainted(false);
        reiniciarBtn.setFocusPainted(false);
        top10Btn.setFocusPainted(false);
        cambiarJugadorBtn.setFocusPainted(false);

        // A�adir los botones al panel
        add(Box.createVerticalStrut(20)); // Espaciado
        add(nuevoBtn);
        add(Box.createVerticalStrut(10)); // Espaciado
        add(reiniciarBtn);
        add(Box.createVerticalStrut(10)); // Espaciado
        add(top10Btn);
        add(Box.createVerticalStrut(10)); // Espaciado
        add(cambiarJugadorBtn);

        // A�adir ActionListener a los botones
        nuevoBtn.addActionListener(actionListener);
        reiniciarBtn.addActionListener(actionListener);
        top10Btn.addActionListener(actionListener);
        cambiarJugadorBtn.addActionListener(actionListener);
    }
}
