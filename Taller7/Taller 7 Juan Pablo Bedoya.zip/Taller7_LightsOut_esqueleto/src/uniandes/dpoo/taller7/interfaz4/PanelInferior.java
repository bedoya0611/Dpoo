package uniandes.dpoo.taller7.interfaz4;

import javax.swing.*;
import java.awt.*;

public class PanelInferior extends JPanel {
	private static final long serialVersionUID = 1L;
	JLabel jugadasLabel;
    JTextField jugadasField;
    JLabel jugadorLabel;
    JTextField jugadorField;

    public PanelInferior() {
        // Configurar el layout del panel
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setBackground(new Color(60, 63, 65));

        // Crear los elementos del panel
        jugadasLabel = new JLabel("Jugadas:");
        jugadasField = new JTextField(5);
        jugadasField.setEditable(false);
        jugadorLabel = new JLabel("Jugador:");
        jugadorField = new JTextField(10);

        // Personalizar apariencia
        jugadasLabel.setForeground(Color.WHITE);
        jugadorLabel.setForeground(Color.WHITE);
        jugadasField.setBackground(new Color(43, 43, 43));
        jugadasField.setForeground(Color.WHITE);
        jugadorField.setBackground(new Color(43, 43, 43));
        jugadorField.setForeground(Color.WHITE);

        // A�adir los elementos al panel
        add(jugadasLabel);
        add(jugadasField);
        add(jugadorLabel);
        add(jugadorField);
    }
}
