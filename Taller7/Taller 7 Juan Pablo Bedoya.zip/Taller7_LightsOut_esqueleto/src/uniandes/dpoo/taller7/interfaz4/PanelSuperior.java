package uniandes.dpoo.taller7.interfaz4;

import javax.swing.*;
import java.awt.*;

public class PanelSuperior extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel tamanoLabel;
    JComboBox<String> tamanoCombo;
    JLabel dificultadLabel;
    JRadioButton facilBtn;
    JRadioButton medioBtn;
    JRadioButton dificilBtn;
    ButtonGroup dificultadGroup;

    public PanelSuperior() {
        // Configurar el layout del panel
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setBackground(new Color(60, 63, 65));
        
        // Crear los elementos del panel
        tamanoLabel = new JLabel("Tama�o:");
        tamanoCombo = new JComboBox<>(new String[]{"5x5", "7x7", "10x10"});
        dificultadLabel = new JLabel("Dificultad:");
        facilBtn = new JRadioButton("F�cil");
        medioBtn = new JRadioButton("Medio");
        dificilBtn = new JRadioButton("Dif�cil");

        // Agrupar los radio buttons
        dificultadGroup = new ButtonGroup();
        dificultadGroup.add(facilBtn);
        dificultadGroup.add(medioBtn);
        dificultadGroup.add(dificilBtn);

        // Personalizar apariencia
        tamanoLabel.setForeground(Color.WHITE);
        dificultadLabel.setForeground(Color.WHITE);
        facilBtn.setForeground(Color.WHITE);
        medioBtn.setForeground(Color.WHITE);
        dificilBtn.setForeground(Color.WHITE);
        facilBtn.setBackground(new Color(60, 63, 65));
        medioBtn.setBackground(new Color(60, 63, 65));
        dificilBtn.setBackground(new Color(60, 63, 65));
        
        tamanoCombo.setForeground(Color.WHITE);
        tamanoCombo.setBackground(new Color(43, 43, 43));

        // A�adir los elementos al panel
        add(tamanoLabel);
        add(tamanoCombo);
        add(dificultadLabel);
        add(facilBtn);
        add(medioBtn);
        add(dificilBtn);
    }
}
