package uniandes.dpoo.taller7.interfaz4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelTablero extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int tamano = 5; // Tama�o inicial del tablero
    private boolean[][] luces; // Matriz para el estado de las luces

    public PanelTablero() {
        setPreferredSize(new Dimension(500, 500)); // Tama�o preferido del panel
        setBackground(new Color(43, 43, 43)); // Fondo del tablero
        luces = new boolean[tamano][tamano]; // Inicializar matriz de luces
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int cellWidth = getWidth() / tamano;
                int cellHeight = getHeight() / tamano;
                int fila = e.getY() / cellHeight;
                int columna = e.getX() / cellWidth;
                cambiarEstado(fila, columna);
            }
        });
    }

    public void setTamano(int nuevoTamano) {
        this.tamano = nuevoTamano;
        luces = new boolean[tamano][tamano]; // Reiniciar matriz de luces
        repaint(); // Redibujar el panel con el nuevo tama�o
    }

    public void setLuces(boolean[][] nuevasLuces) {
        this.luces = nuevasLuces;
        repaint();
    }

    private void cambiarEstado(int fila, int columna) {
        // Cambiar el estado de la luz seleccionada y sus adyacentes
        luces[fila][columna] = !luces[fila][columna];
        if (fila > 0) luces[fila - 1][columna] = !luces[fila - 1][columna];
        if (fila < tamano - 1) luces[fila + 1][columna] = !luces[fila + 1][columna];
        if (columna > 0) luces[fila][columna - 1] = !luces[fila][columna - 1];
        if (columna < tamano - 1) luces[fila][columna + 1] = !luces[fila][columna + 1];
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        int width = getWidth();
        int height = getHeight();
        int cellWidth = width / tamano;
        int cellHeight = height / tamano;

        for (int i = 0; i < tamano; i++) {
            for (int j = 0; j < tamano; j++) {
                int x = j * cellWidth; // Ajuste aqu� para corregir la inversi�n de filas y columnas
                int y = i * cellHeight;
                if (luces[i][j]) {
                    g2d.setColor(Color.YELLOW);
                } else {
                    g2d.setColor(Color.GRAY);
                }
                g2d.fillRect(x, y, cellWidth, cellHeight);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(x, y, cellWidth, cellHeight);
            }
        }
    }
}
