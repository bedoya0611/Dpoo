package uniandes.dpoo.taller7.interfaz4;

import javax.swing.*;
import com.formdev.flatlaf.FlatLightLaf;
import java.io.Serializable;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame implements Serializable, ActionListener {

    private static final long serialVersionUID = 1L;

    private PanelSuperior panelSuperior;
    private PanelDerecha panelDerecha;
    private PanelInferior panelInferior;
    private PanelTablero panelTablero;
    private boolean[][] tableroOriginal;
    
    public VentanaPrincipal() {
        // Configurar la ventana principal
        setTitle("Juego de LightsOut");
        setSize(800, 600); // Tama�o por defecto
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setLayout(new BorderLayout());

        // Inicializar los paneles
        panelSuperior = new PanelSuperior();
        panelDerecha = new PanelDerecha(this);
        panelInferior = new PanelInferior();
        panelTablero = new PanelTablero();

        // A�adir los paneles a la ventana principal
        add(panelSuperior, BorderLayout.NORTH);
        add(panelDerecha, BorderLayout.EAST);
        add(panelInferior, BorderLayout.SOUTH);
        add(panelTablero, BorderLayout.CENTER);

        // A�adir listener para el JComboBox en el panel superior
        panelSuperior.tamanoCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedItem = (String) panelSuperior.tamanoCombo.getSelectedItem();
                int nuevoTamano = Integer.parseInt(selectedItem.split("x")[0]);
                panelTablero.setTamano(nuevoTamano);
                tableroOriginal = new boolean[nuevoTamano][nuevoTamano];
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton source = (JButton) e.getSource();
        if (source == panelDerecha.nuevoBtn) {
            // 6a. Crear nuevo tablero
            crearNuevoTablero();
        } else if (source == panelDerecha.reiniciarBtn) {
            // 6b. Reiniciar tablero
            reiniciarTablero();
        } else if (source == panelDerecha.top10Btn) {
            // 6c. Mostrar Top-10
            mostrarTop10();
        } else if (source == panelDerecha.cambiarJugadorBtn) {
            // 6d. Cambiar jugador
            cambiarJugador();
        }
    }

    private void crearNuevoTablero() {
        String selectedItem = (String) panelSuperior.tamanoCombo.getSelectedItem();
        int nuevoTamano = Integer.parseInt(selectedItem.split("x")[0]);
        panelTablero.setTamano(nuevoTamano);
        tableroOriginal = new boolean[nuevoTamano][nuevoTamano];

        // Inicializar el tablero con una configuraci�n inicial aleatoria
        for (int i = 0; i < nuevoTamano; i++) {
            for (int j = 0; j < nuevoTamano; j++) {
                tableroOriginal[i][j] = Math.random() < 0.5;
            }
        }
        panelTablero.setLuces(tableroOriginal);
        panelInferior.jugadasField.setText("0"); // Reset jugadas
    }

    private void reiniciarTablero() {
        panelTablero.setLuces(tableroOriginal);
        panelInferior.jugadasField.setText("0"); // Reset jugadas
    }

    private void mostrarTop10() {
        JDialog dialog = new JDialog(this, "Top 10", true);
        dialog.setSize(300, 400);
        dialog.setLocationRelativeTo(this);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        // Aqu� deber�as cargar los datos reales del top 10
        String top10Data = "1. Jugador1 - 50\n2. Jugador2 - 45\n...";
        textArea.setText(top10Data);

        dialog.add(new JScrollPane(textArea));
        dialog.setVisible(true);
    }

    private void cambiarJugador() {
        String jugador = JOptionPane.showInputDialog(this, "Ingrese nombre del jugador:");
        panelInferior.jugadorField.setText(jugador);
    }

    public static void main(String[] args) {
        // Aplicar el tema FlatLightLaf
        FlatLightLaf.install();

        // Crear y mostrar la ventana principal
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}
